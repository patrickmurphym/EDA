#include <stdio.h>
#include <stdlib.h>
#include "Prueba4.h"

char labels[5] = {'A', 'B','C','D','E'};

struct tree_node* MaxST(int graph[5][5], int size)
{   
    /*
    Params:
    - graph: Matriz de adyacencia
    Returns:
    Puntero p que apunta al inicio del arbol MaxST
    */
    return NULL;
}

struct list_node* Amigos_Sugeridos(int graph[5][5],int size, struct tree_node *tree, char name)
{   
    /*
    Params:
    - graph: Matriz de adyacencia
    - tree: Puntero al inicio del arbol
    - name: Caracter
    Returns:
    Puntero p que apunta al inicio de la lista con los amigos sugeridos
    */

    return NULL;
}